from flask import Flask, request, jsonify, render_template
import json

app = Flask(__name__)

# Load student data
def load_students():
    with open('students.json') as f:
        return json.load(f)

@app.route('/')
def home():
    return open('index.html').read()

@app.route('/find-student', methods=['POST'])
def find_student():
    standard = request.form['standard']
    section = request.form['section']
    roll = request.form['roll']
    
    students = load_students()
    for student in students:
        if student['standard'] == standard and student['section'] == section and student['roll'] == roll:
            return jsonify({'found': True, 'name': student['name']})
    
    return jsonify({'found': False})

@app.route('/check', methods=['POST'])
def check():
    standard = request.form['standard']
    section = request.form['section']
    roll = request.form['roll']
    dob = request.form['dob']

    students = load_students()
    for student in students:
        if (student['standard'] == standard and 
            student['section'] == section and 
            student['roll'] == roll and 
            student['dob'] == dob):
            # Show marksheet page (you can render a real template here)
            return f"""
            <h2>Marksheet for {student['name']}</h2>
            <ul>
                <li>Math: {student['marks']['Math']}</li>
                <li>Science: {student['marks']['Science']}</li>
                <li>English: {student['marks']['English']}</li>
            </ul>
            """
    return "Invalid DOB. Access denied."

if __name__ == '__main__':
    app.run(debug=True)
